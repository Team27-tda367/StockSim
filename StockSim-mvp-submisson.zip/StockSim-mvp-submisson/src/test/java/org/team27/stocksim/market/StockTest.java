package org.team27.stocksim.market;

class StockTest {

}