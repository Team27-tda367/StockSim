package org.team27.stocksim.ui.fx;

import org.team27.stocksim.model.market.StockSim;
import org.team27.stocksim.model.market.StockSimListener;
import org.team27.stocksim.model.market.Trade;
import org.team27.stocksim.observer.TradingModelListener;
import org.team27.stocksim.ui.fx.viewControllers.TradingViewController;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.util.ArrayList;

public class MainViewAdapter extends StockSimListener implements TradingModelListener {

    private final StockSim model;
    private final StringProperty message = new SimpleStringProperty("");
    private TradingViewController tradingViewController;

    public MainViewAdapter(StockSim model) {
        this.model = model;

        // Initialize properties with model data
        this.message.set(model.messageCreatedStock());

        // Add self as listener to model
        model.addListener(this);
        model.addTradingListener(this);
    }

    public void dispose() {
        model.removeListener(this);
        model.removeTradingListener(this);
    }

    public void setTradingViewController(TradingViewController controller) {
        this.tradingViewController = controller;
    }

    // Exponera property till GUI
    public StringProperty messageProperty() {
        return message;
    }

    // Connect model updates to adapter properties
    @Override
    public void messageChanged(String newMessage) {
        // uppdatera JavaFX-property på FX-tråden
        Platform.runLater(() -> message.set(newMessage));
    }

    // TradingModelListener implementation
    @Override
    public void onOrderPlaced(String stockSymbol, int quantity, String traderId, boolean isBuyOrder) {
        String orderType = isBuyOrder ? "BUY" : "SELL";
        String logMessage = String.format("Order Placed: %s %s %d shares of %s",
                traderId, orderType, quantity, stockSymbol);

        runOnUIThread(() -> {
            if (tradingViewController != null) {
                tradingViewController.appendLog(logMessage);
            }
            System.out.println(logMessage);
        });
    }

    @Override
    public void onTradeExecuted(Trade trade, String buyerTraderId, String sellerTraderId) {
        String logMessage = String.format("Trade Executed: %s bought %d shares of %s from %s at price %s",
                buyerTraderId,
                trade.getQuantity(),
                trade.getStockSymbol(),
                sellerTraderId,
                trade.getPrice());

        runOnUIThread(() -> {
            if (tradingViewController != null) {
                tradingViewController.appendLog(logMessage);
                tradingViewController.updateStatus("Trade executed successfully");
            }
            System.out.println(logMessage);
        });
    }

    @Override
    public void onFetchStocks(ArrayList<ArrayList> stockInfo) {
        runOnUIThread(() -> {
            if (tradingViewController != null) {
                tradingViewController.updateStockList(stockInfo);
            }
        });
    }

    private void runOnUIThread(Runnable action) {
        try {
            Platform.runLater(action);
        } catch (IllegalStateException e) {
            // JavaFX not initialized, run directly (useful for testing)
            action.run();
        }
    }
}
