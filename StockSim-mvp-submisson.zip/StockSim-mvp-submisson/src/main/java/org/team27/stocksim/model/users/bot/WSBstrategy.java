package org.team27.stocksim.model.users.bot;

import org.team27.stocksim.model.market.StockSim;
import org.team27.stocksim.model.users.Bot;

public class WSBstrategy implements BotStrategy {

    @Override
    public void decide(StockSim model, Bot bot) {
        return;
    }

}
