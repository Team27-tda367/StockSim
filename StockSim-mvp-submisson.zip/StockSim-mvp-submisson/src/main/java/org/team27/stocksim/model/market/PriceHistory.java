package org.team27.stocksim.model.market;

public class PriceHistory {
}
