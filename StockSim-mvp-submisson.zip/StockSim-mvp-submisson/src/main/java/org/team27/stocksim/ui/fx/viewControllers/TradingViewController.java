package org.team27.stocksim.ui.fx.viewControllers;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import org.team27.stocksim.controller.SimController;
import org.team27.stocksim.observer.TradingViewListener;
import org.team27.stocksim.ui.fx.MainViewAdapter;
import org.team27.stocksim.ui.fx.dialogs.TradeDialog;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * JavaFX controller for the trading UI.
 * Handles user input and delegates actions through the SimController.
 */
public class TradingViewController extends ViewController {

    @FXML
    private ListView<ArrayList<String>> stockListView;

    @FXML
    private TextArea logTextArea;

    private ObservableList<ArrayList<String>> stockList;
    private List<TradingViewListener> listeners;
    private List<String> availableTraders;

    public TradingViewController(SimController simController, MainViewAdapter viewAdapter) {
        super(simController, viewAdapter);
        this.listeners = new ArrayList<>();
        this.availableTraders = new ArrayList<>();

        // Initialize with default traders
        availableTraders.add("USER1");
        availableTraders.add("USER2");
        availableTraders.add("USER3");
    }

    @FXML
    private void initialize() {
        // Initialize the stock list
        stockList = FXCollections.observableArrayList();
        stockListView.setItems(stockList);

        // Set a custom cell factory to display stock items
        stockListView.setCellFactory(listView -> new StockListCell(this));

        // Fetch current stocks from the model
        simController.fetchStocks();

        System.out.println("TradingViewController initialized");
    }

    public void addListener(TradingViewListener listener) {
        listeners.add(listener);
    }

    public void removeListener(TradingViewListener listener) {
        listeners.remove(listener);
    }

    public void updateStockList(ArrayList<ArrayList> stockInfo) {
        Platform.runLater(() -> {
            stockList.clear();
            for (ArrayList stockArray : stockInfo) {
                stockList.add((ArrayList<String>) stockArray);
            }
            System.out.println("Stock list updated with " + stockInfo.size() + " stocks");
        });
    }


    private void showTradeDialog(String stockSymbol, String stockName, String stockPrice) {
        TradeDialog dialog = new TradeDialog(stockSymbol, stockName, stockPrice, availableTraders);
        Optional<TradeDialog.TradeResult> result = dialog.showAndWait();

        result.ifPresent(tradeResult -> {
            if (tradeResult.isBuy()) {
                placeBuyOrder(tradeResult.getStockSymbol(),
                             tradeResult.getQuantity(),
                             tradeResult.getTraderId());
            } else {
                placeSellOrder(tradeResult.getStockSymbol(),
                              tradeResult.getQuantity(),
                              tradeResult.getTraderId());
            }
        });
    }


    public void placeBuyOrder(String stockSymbol, int quantity, String traderId) {
        for (TradingViewListener listener : listeners) {
            listener.onBuyAction(stockSymbol, quantity, traderId);
        }
        simController.placeBuyOrder(stockSymbol, quantity, traderId);

        String message = String.format("BUY ORDER: %s placed order to buy %d shares of %s",
                                      traderId, quantity, stockSymbol);
        appendLog(message);
    }


    public void placeSellOrder(String stockSymbol, int quantity, String traderId) {
        for (TradingViewListener listener : listeners) {
            listener.onSellAction(stockSymbol, quantity, traderId);
        }
        simController.placeSellOrder(stockSymbol, quantity, traderId);

        String message = String.format("SELL ORDER: %s placed order to sell %d shares of %s",
                                      traderId, quantity, stockSymbol);
        appendLog(message);
    }

    public void fetchStocks() {
        for (TradingViewListener listener : listeners) {
            listener.onFetchStocks();
        }
        simController.fetchStocks();
    }

    public void appendLog(String message) {
        Platform.runLater(() -> {
            if (logTextArea != null) {
                String timestamp = java.time.LocalTime.now().format(
                    java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"));
                logTextArea.appendText(String.format("[%s] %s%n", timestamp, message));
            }
            System.out.println(message);
        });
    }

    public void updateStatus(String status) {
        Platform.runLater(() -> {
            appendLog("STATUS: " + status);
        });
    }

    // ListCell object for displaying Stock items from 2D array
    private static class StockListCell extends ListCell<ArrayList<String>> {
        private final HBox content;
        private final Label symbol;
        private final Label meta;
        private final Button actionButton;
        private final TradingViewController controller;

        public StockListCell(TradingViewController controller) {
            this.controller = controller;

            symbol = new Label();
            symbol.getStyleClass().add("stock-symbol");
            meta = new Label();
            meta.getStyleClass().add("stock-meta");

            VBox stockInfo = new VBox(symbol, meta);
            stockInfo.getStyleClass().add("stock-info");

            // Create a spacer region to push the button to the right
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            // Trade button
            actionButton = new Button("Trade");
            actionButton.getStyleClass().add("btn-highlighted");
            actionButton.setOnAction(event -> {
                ArrayList<String> stock = getItem();
                if (stock != null && stock.size() >= 3) {
                    controller.showTradeDialog(stock.get(0), stock.get(1), stock.get(2));
                }
            });

            content = new HBox(stockInfo, spacer, actionButton);
            content.setAlignment(Pos.CENTER_LEFT);
            content.getStyleClass().add("content");
        }

        @Override
        protected void updateItem(ArrayList<String> stock, boolean empty) {
            super.updateItem(stock, empty);

            if (empty || stock == null || stock.size() < 3) {
                setText(null);
                setGraphic(null);
            } else {
                // stock format: [0] = symbol, [1] = name, [2] = price
                symbol.setText(stock.get(0));
                meta.setText(stock.get(1) + " - $" + stock.get(2));
                setGraphic(content);
            }
        }
    }
}
