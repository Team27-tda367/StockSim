package org.team27.stocksim.model.market;

public interface MarketState {
}
