package org.team27.stocksim.model.market;

public class StockSimListener {
    public void messageChanged(String newMessage) {
    }
}
