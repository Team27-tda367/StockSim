package org.team27.stocksim;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/* OLD */
import org.team27.stocksim.controller.SimController;
import org.team27.stocksim.controller.SimControllerImpl;
import org.team27.stocksim.model.db.Database;
import org.team27.stocksim.model.market.StockSim;
import org.team27.stocksim.ui.fx.ViewSwitcher;
import org.team27.stocksim.ui.fx.viewControllers.CreateStockPageController;
import org.team27.stocksim.ui.fx.viewControllers.MainViewController;
import org.team27.stocksim.ui.fx.viewControllers.StockViewController;
import org.team27.stocksim.ui.fx.MainViewAdapter;

public class Main extends Application {

    @Override
    public void init() throws Exception {
        super.init();
        // Starta databasen innan UI
        Database.init();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        // creating model
        StockSim model = new StockSim();

        // Initialize demo data
        initializeDemoData(model);

        // Create fascade controller for model
        SimController simController = new SimControllerImpl(model);

        // Create ViewAdapter
        MainViewAdapter viewAdapter = new MainViewAdapter(model);

        // Set up shared controller factory for all views
        ViewSwitcher.setControllerFactory(type -> {
            if (type == MainViewController.class) {
                return new MainViewController(simController, viewAdapter);
            }
            if (type == CreateStockPageController.class) {
                return new CreateStockPageController(simController, viewAdapter);
            }
            if (type == StockViewController.class) {
                return new StockViewController(simController, viewAdapter);
            }
            if (type == org.team27.stocksim.ui.fx.viewControllers.TradingViewController.class) {
                org.team27.stocksim.ui.fx.viewControllers.TradingViewController controller =
                    new org.team27.stocksim.ui.fx.viewControllers.TradingViewController(simController, viewAdapter);
                viewAdapter.setTradingViewController(controller);
                return controller;
            }
            try {
                return type.getDeclaredConstructor().newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        // Create FXML loader for initial view
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/team27/stocksim/view/main_view.fxml"));
        loader.setControllerFactory(ViewSwitcher.getControllerFactory());

        // Load FXML. The controller is created by the factory
        Parent root = loader.load();

        Scene scene = new Scene(root);
        ViewSwitcher.setScene(scene);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Stocksim");
        primaryStage.show();
    }

    @Override
    public void stop() throws Exception {
        // Stäng databasen snyggt
        Database.close();
        super.stop();
    }


    private void initializeDemoData(StockSim model) {
        // Create some demo stocks
        model.createStock("AAPL", "Apple Inc.", "0.01", "1");
        model.createStock("GOOGL", "Alphabet Inc.", "0.01", "1");
        model.createStock("MSFT", "Microsoft Corp.", "0.01", "1");
        model.createStock("TSLA", "Tesla Inc.", "0.01", "1");
        model.createStock("AMZN", "Amazon.com Inc.", "0.01", "1");

        // Set initial prices for stocks
        org.team27.stocksim.model.market.Stock appleStock = model.getStock("AAPL");
        if (appleStock != null) appleStock.setCurrentPrice(new java.math.BigDecimal("150.25"));

        org.team27.stocksim.model.market.Stock googleStock = model.getStock("GOOGL");
        if (googleStock != null) googleStock.setCurrentPrice(new java.math.BigDecimal("140.50"));

        org.team27.stocksim.model.market.Stock msftStock = model.getStock("MSFT");
        if (msftStock != null) msftStock.setCurrentPrice(new java.math.BigDecimal("380.75"));

        org.team27.stocksim.model.market.Stock teslaStock = model.getStock("TSLA");
        if (teslaStock != null) teslaStock.setCurrentPrice(new java.math.BigDecimal("245.30"));

        org.team27.stocksim.model.market.Stock amznStock = model.getStock("AMZN");
        if (amznStock != null) amznStock.setCurrentPrice(new java.math.BigDecimal("175.80"));

        // Create demo users with portfolios
        model.createUser("USER1", "Alice");
        model.createUser("USER2", "Bob");
        model.createUser("USER3", "Charlie");

    }

    public static void main(String[] args) {
        // start Java-FX app
        launch(args);
    }

}