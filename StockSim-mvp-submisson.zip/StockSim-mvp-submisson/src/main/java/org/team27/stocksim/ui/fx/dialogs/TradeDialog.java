package org.team27.stocksim.ui.fx.dialogs;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

import java.util.List;

/**
 * Dialog for placing buy or sell orders.
 */
public class TradeDialog extends Dialog<TradeDialog.TradeResult> {

    private final ToggleGroup tradeTypeGroup;
    private final RadioButton buyRadio;
    private final RadioButton sellRadio;
    private final TextField quantityField;
    private final ComboBox<String> traderComboBox;
    private final String stockSymbol;

    public TradeDialog(String stockSymbol, String stockName, String stockPrice, List<String> traders) {
        this.stockSymbol = stockSymbol;

        setTitle("Trade " + stockSymbol);
        setHeaderText("Place an order for " + stockName + " (" + stockSymbol + ")\nCurrent Price: $" + stockPrice);

        // Create the custom dialog content
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        // Trade type selection
        Label tradeTypeLabel = new Label("Action:");
        tradeTypeGroup = new ToggleGroup();
        buyRadio = new RadioButton("Buy");
        buyRadio.setToggleGroup(tradeTypeGroup);
        buyRadio.setSelected(true);
        sellRadio = new RadioButton("Sell");
        sellRadio.setToggleGroup(tradeTypeGroup);

        HBox tradeTypeBox = new HBox(10, buyRadio, sellRadio);

        // Quantity input
        Label quantityLabel = new Label("Quantity:");
        quantityField = new TextField();
        quantityField.setPromptText("Enter quantity");
        quantityField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                quantityField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        // Trader selection
        Label traderLabel = new Label("Trader:");
        traderComboBox = new ComboBox<>();
        traderComboBox.getItems().addAll(traders);
        if (!traders.isEmpty()) {
            traderComboBox.getSelectionModel().selectFirst();
        }
        traderComboBox.setPromptText("Select trader");

        // Add fields to grid
        grid.add(tradeTypeLabel, 0, 0);
        grid.add(tradeTypeBox, 1, 0);
        grid.add(quantityLabel, 0, 1);
        grid.add(quantityField, 1, 1);
        grid.add(traderLabel, 0, 2);
        grid.add(traderComboBox, 1, 2);

        getDialogPane().setContent(grid);

        // Add buttons
        ButtonType tradeButtonType = new ButtonType("Place Order", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(tradeButtonType, ButtonType.CANCEL);

        // Disable trade button initially
        Button tradeButton = (Button) getDialogPane().lookupButton(tradeButtonType);
        tradeButton.setDisable(true);

        // Enable/disable trade button based on input
        quantityField.textProperty().addListener((observable, oldValue, newValue) -> {
            tradeButton.setDisable(newValue.trim().isEmpty() ||
                                   traderComboBox.getValue() == null ||
                                   Integer.parseInt(newValue.isEmpty() ? "0" : newValue) <= 0);
        });

        traderComboBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            tradeButton.setDisable(quantityField.getText().trim().isEmpty() ||
                                   newValue == null);
        });

        // Convert result when trade button is clicked
        setResultConverter(dialogButton -> {
            if (dialogButton == tradeButtonType) {
                try {
                    int quantity = Integer.parseInt(quantityField.getText());
                    String trader = traderComboBox.getValue();
                    boolean isBuy = buyRadio.isSelected();
                    return new TradeResult(stockSymbol, quantity, trader, isBuy);
                } catch (NumberFormatException e) {
                    return null;
                }
            }
            return null;
        });
    }

    /**
     * Result class containing trade order details.
     */
    public static class TradeResult {
        private final String stockSymbol;
        private final int quantity;
        private final String traderId;
        private final boolean isBuy;

        public TradeResult(String stockSymbol, int quantity, String traderId, boolean isBuy) {
            this.stockSymbol = stockSymbol;
            this.quantity = quantity;
            this.traderId = traderId;
            this.isBuy = isBuy;
        }

        public String getStockSymbol() {
            return stockSymbol;
        }

        public int getQuantity() {
            return quantity;
        }

        public String getTraderId() {
            return traderId;
        }

        public boolean isBuy() {
            return isBuy;
        }
    }
}

