package org.team27.stocksim.model.market;

import org.team27.stocksim.model.portfolio.Portfolio;
import org.team27.stocksim.model.users.*;
import org.team27.stocksim.observer.TradingModelListener;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static org.team27.stocksim.model.util.MoneyUtils.money;

public class StockSim {
    /* Listeners */
    private final List<StockSimListener> listeners = new ArrayList<>();
    private final List<TradingModelListener> tradingListeners = new ArrayList<>();
    MarketState state;
    HashMap<String, Instrument> stocks;
    InstrumentFactory stockFactory;
    HashMap<String, Trader> traders;
    TraderFactory userFactory;
    TraderFactory botFactory;
    private String createdStockMsg = "Initial message";
    private MatchingEngine matchingEngine;
    private HashMap<String, OrderBook> orderBooks;
    private HashMap<Integer, String> orderIdToTraderId; // maps order ID to trader ID

    public StockSim() {
        // Stock related inits
        stocks = new HashMap<>();
        stockFactory = new StockFactory();

        // Trader related inits
        orderBooks = new HashMap<>();
        traders = new HashMap<>();
        userFactory = new UserFactory();
        botFactory = new BotFactory();
        matchingEngine = new MatchingEngine();
        orderIdToTraderId = new HashMap<>();

        System.out.println("Succesfully created Sim-model");
    }

    public String messageCreatedStock() {
        return createdStockMsg;
    }

    public void addListener(StockSimListener l) {
        listeners.add(l);
    }

    public void removeListener(StockSimListener l) {
        listeners.remove(l);
    }

    private void notifyListeners(String newMessage) {
        for (StockSimListener l : List.copyOf(listeners)) {
            l.messageChanged(newMessage);
        }
    }

    public void addTradingListener(TradingModelListener listener) {
        tradingListeners.add(listener);
    }

    public void removeTradingListener(TradingModelListener listener) {
        tradingListeners.remove(listener);
    }

    private void notifyOrderPlaced(String stockSymbol, int quantity, String traderId, boolean isBuyOrder) {
        for (TradingModelListener listener : List.copyOf(tradingListeners)) {
            listener.onOrderPlaced(stockSymbol, quantity, traderId, isBuyOrder);
        }
    }

    private void notifyTradeExecuted(Trade trade, String buyerTraderId, String sellerTraderId) {
        for (TradingModelListener listener : List.copyOf(tradingListeners)) {
            listener.onTradeExecuted(trade, buyerTraderId, sellerTraderId);
        }
    }

    private void notifyFetchStocks(ArrayList<ArrayList> stockInfo) {
        for (TradingModelListener listener : List.copyOf(tradingListeners)) {
            listener.onFetchStocks(stockInfo);
        }
    }

    // OrderBook logic and Matching Engine
    public void addOrderBook(String symbol, OrderBook orderBook) {
        orderBooks.put(symbol, orderBook);
    }

    public void removeOrderBook(String symbol) {
        orderBooks.remove(symbol);
    }

    public OrderBook getOrderBook(String symbol) {
        OrderBook book = orderBooks.computeIfAbsent(
                symbol,
                OrderBook::new
        );
        return orderBooks.get(symbol);
    }

    public void placeOrder(Order order) {
        //TODO: validation of order (enough balance, enough stocks in portfolio, lot size, tick size, etc)
        // Track the order ID to trader ID mapping
        orderIdToTraderId.put(order.getOrderId(), order.getTraderId());

        // Notify listeners about order placement
        boolean isBuyOrder = order.getSide() == Order.Side.BUY;
        notifyOrderPlaced(order.getSymbol(), order.getTotalQuantity(), order.getTraderId(), isBuyOrder);

        processOrder(order);
    } //TODO: seperate order placing logic from processing logic


    public void placeBuyOrder(String stockSymbol, int quantity, String traderId) {
        Order buyOrder = new Order(Order.Side.BUY, stockSymbol,
                                   System.identityHashCode(this),
                                   money("100"), quantity, traderId);
        placeOrder(buyOrder);
    }


    public void placeSellOrder(String stockSymbol, int quantity, String traderId) {
        Order sellOrder = new Order(Order.Side.SELL, stockSymbol,
                                    System.identityHashCode(this),
                                    money("100"), quantity, traderId);
        placeOrder(sellOrder);
    }

    /**
     * Fetch current stock information and notify listeners.
     */
    public void fetchStocks() {
        ArrayList<ArrayList> stockInfo = new ArrayList<>();
        for (Instrument instrument : stocks.values()) {
            if (instrument instanceof Stock) {
                Stock stock = (Stock) instrument;
                BigDecimal price = stock.getCurrentPrice();
                String priceStr = (price != null) ? price.toString() : "0.00";
                stockInfo.add(new ArrayList<>(Arrays.asList(
                        stock.getSymbol(),
                        stock.getName(),
                        priceStr
                )));
            }
        }
        notifyFetchStocks(stockInfo);
    }


    public Stock getStock(String symbol) {
        Instrument instrument = stocks.get(symbol.toUpperCase());
        if (instrument instanceof Stock) {
            return (Stock) instrument;
        }
        return null;
    }

    private void processOrder(Order order) {

        List<Trade> trades = matchingEngine.match(order, getOrderBook(order.getSymbol()));

        for (Trade trade : trades) {
            settleTrade(trade);
        }
    }

    private void settleTrade(Trade trade) {
        String buyerTraderId = orderIdToTraderId.get(trade.getBuyOrderId());
        String sellerTraderId = orderIdToTraderId.get(trade.getSellOrderId());

        if (buyerTraderId == null || sellerTraderId == null) {
            //TODO: handle error
            return;
        }


        Trader buyer = traders.get(buyerTraderId);
        Trader seller = traders.get(sellerTraderId);

        if (buyer == null || seller == null) {
            //TODO: handle error
            return;
        }


        BigDecimal tradeValue = trade.getPrice().multiply(BigDecimal.valueOf(trade.getQuantity()));


        Portfolio buyerPortfolio = buyer.getPortfolio();
        Portfolio sellerPortfolio = seller.getPortfolio();

        if (buyerPortfolio.withdraw(tradeValue)) {
            sellerPortfolio.deposit(tradeValue);

            sellerPortfolio.removeStock(trade.getStockSymbol(), trade.getQuantity());
            buyerPortfolio.addStock(trade.getStockSymbol(), trade.getQuantity());

            // Notify listeners about the executed trade
            notifyTradeExecuted(trade, buyerTraderId, sellerTraderId);
        } else {
            //TODO: handle error
        }
    }

    public void createStock(String symbol, String stockName, String tickSize, String lotSize) {
        // checking if symbol already exists (if yes -> error)
        String highSymbol = symbol.toUpperCase();
        if (stocks.containsKey(highSymbol)) {
            createdStockMsg = "Symbol already exists!";
        } else {
            Instrument stock = stockFactory.createInstrument(highSymbol, stockName, new BigDecimal(tickSize), Integer.parseInt(lotSize));
            stocks.put(highSymbol, stock);
            String createdStock = highSymbol + " " + stockName + " " + tickSize + " " + lotSize;
            createdStockMsg = createdStock;
        }

        notifyListeners(createdStockMsg);
    }

    // Trader logic
    public void createUser(String id, String name) {
        String highId = id.toUpperCase();
        if (traders.containsKey(highId)) {
            System.out.println("userID already exists");
        } else {
            Portfolio portfolio = createPortfolio(highId);
            Trader user = userFactory.createTrader(highId, name, portfolio);
            traders.put(highId, user);
        }
    }

    public void createBot(String id, String name) {
        String highId = id.toUpperCase();
        if (traders.containsKey(highId)) {
            System.out.println("botID already exists");
        } else {
            Portfolio portfolio = createPortfolio(highId);
            Trader bot = botFactory.createTrader(highId, name, portfolio);
            traders.put(highId, bot);
        }
    }

    // Getters
    public HashMap<String, Instrument> getStocks() {
        return stocks;
    }

    public HashMap<String, Trader> getTraders() {
        return traders;
    }

    public HashMap<String, Trader> getBots() {
        HashMap<String, Trader> bots = new HashMap<>();
        for (String id : traders.keySet()) {
            Trader trader = traders.get(id);
            if (trader instanceof Bot) {
                bots.put(id, trader);
            }
        }
        return bots;
    }

    public Portfolio createPortfolio(String id) {
        // if id in portfolio-db, fetch balance and insert, else -> new User/Bot, insert
        // startingBalance
        BigDecimal startingBalance = money("10000");
        return new Portfolio(startingBalance);
    }

}

