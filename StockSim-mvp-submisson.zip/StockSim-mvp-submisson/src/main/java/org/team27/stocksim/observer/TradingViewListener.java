package org.team27.stocksim.observer;


public interface TradingViewListener {

    void onBuyAction(String stockSymbol, int quantity, String traderId);

    void onSellAction(String stockSymbol, int quantity, String traderId);

    void onFetchStocks();
}

