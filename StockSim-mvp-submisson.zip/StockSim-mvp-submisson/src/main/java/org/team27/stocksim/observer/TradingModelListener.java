package org.team27.stocksim.observer;

import org.team27.stocksim.model.market.Trade;

import java.util.ArrayList;

public interface TradingModelListener {

    void onOrderPlaced(String stockSymbol, int quantity, String traderId, boolean isBuyOrder);

    void onTradeExecuted(Trade trade, String buyerTraderId, String sellerTraderId);

    void onFetchStocks(ArrayList<ArrayList> stockInfo);
}


