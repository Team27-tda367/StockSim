package org.team27.stocksim.controller;

public interface SimController {

    void createStock(String symbol, String stockName, String tickSize, String lotSize);

    /**
     * Place a buy order for a specific trader.
     * @param stockSymbol the stock symbol to buy
     * @param quantity the quantity to buy
     * @param traderId the ID of the trader placing the order
     */
    void placeBuyOrder(String stockSymbol, int quantity, String traderId);

    /**
     * Place a sell order for a specific trader.
     * @param stockSymbol the stock symbol to sell
     * @param quantity the quantity to sell
     * @param traderId the ID of the trader placing the order
     */
    void placeSellOrder(String stockSymbol, int quantity, String traderId);

    /**
     * Fetch current stock information.
     */
    void fetchStocks();

    // All other method signatures that calls the model layer

}
